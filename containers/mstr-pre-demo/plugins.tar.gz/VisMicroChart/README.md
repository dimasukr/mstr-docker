**Contributor:** MicroStrategy, Inc.

**Contributor's Contact Info.:** <fniug@microstrategy.com>

**Contributor's Orgnization:** MicroStrategy, Inc.

**Original Author:** Microstrategy

**Original Author's Orgnization:** Microstrategy

**Original Author's Contact Info.:** 

**Original Visualization Source Link:** 

**Usage:** This visualization at least needs 1 or more attributes and 1 metric.

**Description:** A Microcharts widget is made up of several small types of graphs or charts. You can format some aspects of the entire Microcharts widget, or format a specific type of microchart in the widget.


**Screenshot:**

![Alt text][screenshot]
[screenshot]: ./style/images/screenshot.png?raw=true
